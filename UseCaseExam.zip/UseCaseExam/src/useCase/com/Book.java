package useCase.com;

public class Book extends Library {

	public Book() {
		super();
	}
	
	
	

	@Override
	public void lateFeeCalculation() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void overdueNotification() {
		// TODO Auto-generated method stub
		
	}




	@Override
	public void BorrwingItems() {
		// TODO Auto-generated method stub
		
	}




	@Override
	public void returnItems() {
		// TODO Auto-generated method stub
		
	}




	@Override
	public void cheackAvailability() {
		// TODO Auto-generated method stub
		
	}

}
