package useCase.com;

public class Magazine extends Library{

	public Magazine() {
		super();
	}

	@Override
	public void lateFeeCalculation() {
				
	}

	@Override
	public void overdueNotification() {
	
		
	}

	@Override
	public void BorrwingItems() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void returnItems() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void cheackAvailability() {
		// TODO Auto-generated method stub
		
	}

}
