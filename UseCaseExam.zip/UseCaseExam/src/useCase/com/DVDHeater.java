package useCase.com;

public interface DVDHeater {


	abstract void numOfPages(int pages);

}
